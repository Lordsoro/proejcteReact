<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;
//importar el modelo
use App\Models\User;
//per a cifrar contraseñes
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    function register(Request $req)
    {
        $user = new User;
        $user->user = $req->input('user');
        $user->email = $req->input('email');
        $user->password = Hash::make($req->input('password'));
        $user->country = $req->input('country');
        $user->save();
        return $user;
    }
    public function login(Request $request)
    {
        $credenciales = $request->only('email', 'password');
        if (Auth::attempt($credenciales)) {
            $user = Auth::user();
            $name = $user->user;
            $id = $user->id;
            return response()->json(['success' => true, 'name' => $name, 'id' => $id]);
        } else {
            return response()->json(['success' => false, 'error' => 'Credenciales no validas']);
        }
    }
}
