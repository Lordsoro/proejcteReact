<?php

namespace App\Http\Controllers;

use App\Models\Pedido;
use App\Models\User;
use App\Models\Product;
use Illuminate\Http\Request;

class PedidoController extends Controller
{
    function register(Request $req)
    {
        $user = User::find($req->input('user_id'));
        $product = Product::find($req->input('product_id'));

        $pedido = new Pedido;
        $pedido->user()->associate($user);
        $pedido->product()->associate($product);
        $pedido->quantity = $req->input('quantity');
        $pedido->size = $req->input('size');
        $pedido->total = $product->price * $pedido->quantity;
        $pedido->save();
    }
}
