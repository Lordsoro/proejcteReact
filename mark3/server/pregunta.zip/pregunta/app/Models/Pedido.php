<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use App\Models\Product;

class Pedido extends Model
{
    use HasFactory;
    protected $table = 'pedido';
    protected $fillable = [
        'user_id', 'total', 'status'
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function product()
    {
        return $this->hasMany(Product::class, 'product_id');
    }

    public function createOrder($userId, $total, $status)
    {
        $this->user_id = $userId;
        $this->total = $total;
        $this->status = $status;

        $this->save();

        return $this;
    }
}
